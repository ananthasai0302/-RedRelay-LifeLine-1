import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api, usePoll } from '../api.js';
import RequestCard from '../components/RequestCard.jsx';

export default function Feed() {
  const [list, setList] = useState(null);
  const [err, setErr] = useState('');
  usePoll(() => api.get('/requests').then((d) => { setList(d); setErr(''); }).catch((e) => setErr(e.message)), 5000);

  const active = (list || []).filter((r) => r.status !== 'closed');
  const closed = (list || []).filter((r) => r.status === 'closed');

  return (
    <>
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">{active.length} families need blood right now</h1>
          <p className="mt-1 text-ink/70">Sorted by deadline. Counters refresh every few seconds.</p>
        </div>
        <Link to="/sos" className="btn-red">Post an SOS</Link>
      </div>
      {err && <p className="rounded-lg bg-blood-tint p-3 text-blood-dark">Could not reach the server: {err}. Is the API running on port 4000?</p>}
      {!list && !err && <p>Loading requests…</p>}
      <div className="grid gap-3 md:grid-cols-2">{active.map((r) => <RequestCard key={r.id} r={r} />)}</div>
      {list && active.length === 0 && <p className="rounded-lg bg-white p-4">No open requests. Good news.</p>}
      {closed.length > 0 && (
        <>
          <h2 className="mb-3 mt-8 text-lg font-bold text-ink/70">Recently closed</h2>
          <div className="grid gap-3 md:grid-cols-2">{closed.map((r) => <RequestCard key={r.id} r={r} />)}</div>
        </>
      )}
    </>
  );
}
