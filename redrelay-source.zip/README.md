# RedRelay

Emergency blood requests matched to compatible nearby donors, with donor phone numbers kept private.

## Run it

Needs Node 18+.

```bash
npm run setup     # installs root, server and client dependencies
npm run dev       # API on :4000, web app on :5173
```

Open http://localhost:5173. The SQLite file (`server/redrelay.db`) is created and seeded on first start with 30 donors and 5 open requests. Delete the file to reset the demo.

For one-process mode: `npm run build && npm start`, then open http://localhost:4000.

Tests for the blood compatibility matrix: `npm --prefix server test`.

## How it hangs together

- `server/compat.js` is the ABO/Rh lookup table. Everything else asks it who can give to whom.
- `server/db.js` has the schema (donors, requests, responses) and the seed data.
- `server/index.js` is the REST API. Request status is recomputed on every read, so a request flips to Fulfilled when committed units reach the target and to Closed when it passes its 24 hour expiry.
- `client/` is React, React Router and Tailwind.

## Privacy and safety decisions

- Phone numbers and the doctor's contact are stored but no endpoint returns them. Public views show initials and locality only.
- Only the browser that posted a request holds its token, so only that family can press "Mark blood received".
- Marking blood received locks every donor who gave for 90 days.
- A donor can answer a request once, and an incompatible group is rejected by the server, not just hidden in the UI.

## Known gaps

- "Act as a donor" is a demo shortcut. There is no real login, so don't deploy this publicly as is.
- The doctor contact is collected but not actually verified.
- SMS dispatch is simulated. No messages are sent.
- Distances are straight-line between locality centres, and drive times are estimates. There is no Leaflet map yet.

## Demo script

1. Request blood: 2 units B+, Apollo Hospital, Banjara Hills, 4 hours.
2. On the request page, see B+, B-, O+ and O- donors listed by distance.
3. Go to Donors, act as an O+ donor, open the request, press I Can Donate.
4. The card shows 1/2 units and the stepper moves to Donors Responded. A second donor takes it to Fulfilled.
5. Back on the request (same browser), press Mark blood received. Donors now show a 90 day lock and can download a certificate.
