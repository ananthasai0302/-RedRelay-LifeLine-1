import Database from 'better-sqlite3';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
export const db = new Database(path.join(here, 'redrelay.db'));
db.pragma('journal_mode = WAL');

// Rough centre points for Hyderabad-area localities (lat, lng). Used for the radius filter.
export const LOCALITIES = {
  'Banjara Hills': [17.4126, 78.4482],
  'Ameerpet': [17.4375, 78.4483],
  'Madhapur': [17.4483, 78.3915],
  'Gachibowli': [17.4401, 78.3489],
  'Kukatpally': [17.4948, 78.3996],
  'Secunderabad': [17.4399, 78.4983],
  'Uppal': [17.4018, 78.56],
  'Dilsukhnagar': [17.3688, 78.5247],
  'LB Nagar': [17.3457, 78.5522],
  'Medchal': [17.6297, 78.4814],
};

db.exec(`
CREATE TABLE IF NOT EXISTS donors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  blood_group TEXT NOT NULL,
  locality TEXT NOT NULL,
  phone TEXT NOT NULL,            -- never sent to the client
  available INTEGER NOT NULL DEFAULT 1,
  last_donation INTEGER           -- epoch ms, drives the 90 day lock
);
CREATE TABLE IF NOT EXISTS requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient TEXT NOT NULL,
  hospital TEXT NOT NULL,
  locality TEXT NOT NULL,
  blood_group TEXT NOT NULL,
  units INTEGER NOT NULL,
  deadline_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,    -- hard stop, 24h after creation
  doctor_contact TEXT NOT NULL,   -- never sent to the client
  token TEXT NOT NULL,            -- lets the family (and only them) close the request
  status TEXT NOT NULL DEFAULT 'open',
  closed_reason TEXT,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS responses (   -- fulfilment transactions
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  request_id INTEGER NOT NULL REFERENCES requests(id),
  donor_id INTEGER NOT NULL REFERENCES donors(id),
  units INTEGER NOT NULL DEFAULT 1,
  state TEXT NOT NULL DEFAULT 'committed', -- committed -> donated
  created_at INTEGER NOT NULL,
  UNIQUE (request_id, donor_id)
);
`);

function seed() {
  if (db.prepare('SELECT COUNT(*) n FROM donors').get().n > 0) return;
  const DAY = 864e5, HOUR = 36e5, now = Date.now();
  const names = [
    'Ravi Kumar', 'Sneha Reddy', 'Imran Shaikh', 'Lakshmi Prasad', 'Arjun Naidu',
    'Fatima Begum', 'Kiran Rao', 'Divya Teja', 'Suresh Goud', 'Anitha Varma',
    'Mohan Babu', 'Priya Sharma', 'Venkat Rao', 'Zoya Khan', 'Harish Yadav',
    'Meena Kumari', 'Sai Charan', 'Nikhil Joshi', 'Pooja Menon', 'Rahul Verma',
    'Swathi Chary', 'Farhan Ali', 'Deepa Nair', 'Ganesh Pillai', 'Rekha Devi',
    'Tarun Mehta', 'Bhavana Reddy', 'Asif Hussain', 'Nandini Rao', 'Vamsi Krishna',
  ];
  const groups = ['O+', 'B+', 'A+', 'B+', 'O-', 'AB+', 'B-', 'A-', 'O+', 'AB-'];
  const places = Object.keys(LOCALITIES);
  const ins = db.prepare('INSERT INTO donors (name, blood_group, locality, phone, available, last_donation) VALUES (?,?,?,?,?,?)');
  names.forEach((n, i) => {
    const recentlyDonated = i === 4 || i === 13 ? now - 20 * DAY : null; // two donors still in recovery
    const busy = i === 9 ? 0 : 1;
    ins.run(n, groups[i % groups.length], places[(i * 3) % places.length], `9848${String(100000 + i * 3719).slice(-6)}`, busy, recentlyDonated);
  });

  const mk = db.prepare(`INSERT INTO requests (patient, hospital, locality, blood_group, units, deadline_at, expires_at, doctor_contact, token, status, created_at)
                         VALUES (?,?,?,?,?,?,?,?,?,?,?)`);
  const reqs = [
    ['Ramesh Gupta', 'Apollo Hospital, Jubilee Hills', 'Banjara Hills', 'B+', 2, 4, 'Emergency surgery'],
    ['Sunita Devi', 'Care Hospitals, Kukatpally', 'Kukatpally', 'O-', 3, 2, 'Childbirth complication'],
    ['Abdul Karim', 'Yashoda Hospital, Secunderabad', 'Secunderabad', 'A+', 1, 6, 'Road accident'],
    ['Meghana Rao', 'Continental Hospitals, Gachibowli', 'Gachibowli', 'AB+', 2, 8, 'Trauma surgery'],
    ['Joseph Thomas', 'Medicover, Madhapur', 'Madhapur', 'A-', 2, 3, 'Internal bleeding'],
  ];
  reqs.forEach(([p, h, l, g, u, hrs], i) => {
    const created = now - (i + 1) * 12 * 60e3;
    mk.run(p, h, l, g, u, created + hrs * HOUR, created + 24 * HOUR, '9000000000', `seed-token-${i + 1}`, 'open', created);
  });
}
seed();
