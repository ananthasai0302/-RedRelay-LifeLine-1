import { useEffect, useRef, useState } from 'react';

async function call(url, method = 'GET', body) {
  const res = await fetch('/api' + url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Something went wrong. Try again.');
  return data;
}
export const api = {
  get: (u) => call(u),
  post: (u, b) => call(u, 'POST', b || {}),
  patch: (u, b) => call(u, 'PATCH', b),
};

// Tokens prove "this browser posted the request", so only the family can close it.
export const tokens = {
  all: () => JSON.parse(localStorage.getItem('rr_tokens') || '{}'),
  get: (id) => tokens.all()[id],
  set: (id, t) => localStorage.setItem('rr_tokens', JSON.stringify({ ...tokens.all(), [id]: t })),
};

// Runs fn now and every `ms`. Keeps the latest fn in a ref so closures never go stale.
export function usePoll(fn, ms, deps = []) {
  const ref = useRef(fn);
  ref.current = fn;
  useEffect(() => {
    const run = () => ref.current();
    run();
    const t = setInterval(run, ms);
    return () => clearInterval(t);
  }, deps);
}

let metaPromise;
export function useMeta() {
  const [meta, setMeta] = useState({ localities: [], groups: [] });
  useEffect(() => {
    metaPromise = metaPromise || api.get('/meta');
    metaPromise.then(setMeta).catch(() => {});
  }, []);
  return meta;
}

export function timeLeft(ts) {
  const ms = ts - Date.now();
  if (ms <= 0) return 'deadline passed';
  const m = Math.round(ms / 60000);
  if (m < 60) return `${m} min left`;
  const h = Math.floor(m / 60);
  return `${h}h ${m % 60}m left`;
}
