// ABO / Rh red-cell compatibility. Key = recipient, value = groups that can give to them.
export const GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

const DONORS_FOR = {
  'O-':  ['O-'],
  'O+':  ['O+', 'O-'],
  'A-':  ['A-', 'O-'],
  'A+':  ['A+', 'A-', 'O+', 'O-'],
  'B-':  ['B-', 'O-'],
  'B+':  ['B+', 'B-', 'O+', 'O-'],
  'AB-': ['AB-', 'A-', 'B-', 'O-'],
  'AB+': ['AB+', 'AB-', 'A+', 'A-', 'B+', 'B-', 'O+', 'O-'],
};

export const donorsFor = (recipient) => DONORS_FOR[recipient] || [];
export const canDonate = (donor, recipient) => donorsFor(recipient).includes(donor);
export const recipientsOf = (donor) => GROUPS.filter((r) => canDonate(donor, r));
