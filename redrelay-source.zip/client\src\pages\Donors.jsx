import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Download, ShieldCheck } from 'lucide-react';
import { api, timeLeft, useMeta, usePoll } from '../api.js';

function drawCertificate(name, group, hospital) {
  const c = document.createElement('canvas');
  c.width = c.height = 1080;
  const g = c.getContext('2d');
  g.fillStyle = '#fff'; g.fillRect(0, 0, 1080, 1080);
  g.fillStyle = '#B8142C'; g.fillRect(0, 0, 1080, 220);
  g.fillStyle = '#fff'; g.textAlign = 'center';
  g.font = '800 72px sans-serif'; g.fillText('You saved a life', 540, 140);
  g.fillStyle = '#16222E';
  g.font = '40px sans-serif'; g.fillText('Thank you,', 540, 400);
  g.font = '800 96px sans-serif'; g.fillText(name || 'Donor', 540, 520, 940);
  g.font = '40px sans-serif';
  g.fillText(`for donating ${group} blood at`, 540, 640);
  g.fillText(hospital, 540, 700, 940);
  g.fillStyle = '#B8142C'; g.font = '800 44px sans-serif'; g.fillText('RedRelay volunteer donor', 540, 900);
  g.fillStyle = '#16222E99'; g.font = '28px sans-serif'; g.fillText(new Date().toLocaleDateString(), 540, 960);
  const a = document.createElement('a');
  a.download = 'redrelay-certificate.png'; a.href = c.toDataURL('image/png'); a.click();
}

export default function Donors() {
  const { localities, groups } = useMeta();
  const [list, setList] = useState([]);
  const [me, setMe] = useState(localStorage.getItem('rr_donor') || '');
  const [mine, setMine] = useState(null);
  const [f, setF] = useState({ name: '', bloodGroup: '', locality: '', phone: '' });
  const [msg, setMsg] = useState('');
  const [certName, setCertName] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  usePoll(() => api.get('/donors').then(setList).catch(() => {}), 8000);
  usePoll(() => { if (me) api.get(`/donors/${me}/matches`).then(setMine).catch(() => setMine(null)); }, 5000, [me]);

  const pick = (id) => { setMe(id); id ? localStorage.setItem('rr_donor', id) : localStorage.removeItem('rr_donor'); };
  const refreshMine = async () => setMine(await api.get(`/donors/${me}/matches`));

  async function register(e) {
    e.preventDefault(); setMsg('');
    try {
      const d = await api.post('/donors', f);
      setF({ name: '', bloodGroup: '', locality: '', phone: '' });
      pick(String(d.id)); setMsg('Registered. Your number is stored but never shown to anyone.');
      setList(await api.get('/donors'));
    } catch (x) { setMsg(x.message); }
  }
  async function toggle() {
    try { await api.patch(`/donors/${me}/availability`, { available: !mine.donor.available }); refreshMine(); } catch (x) { setMsg(x.message); }
  }
  async function donate(reqId) {
    try { await api.post(`/requests/${reqId}/respond`, { donorId: Number(me) }); setMsg('Response sent. The family can see you are on the way.'); refreshMine(); } catch (x) { setMsg(x.message); }
  }

  const d = mine?.donor;
  return (
    <div className="grid gap-6 md:grid-cols-2">
      <div className="space-y-6">
        <form onSubmit={register} className="space-y-3 rounded-xl border border-ink/10 bg-white p-5">
          <h1 className="text-xl font-extrabold">Become a donor</h1>
          <p className="flex gap-2 text-sm text-ink/70"><ShieldCheck size={18} className="shrink-0 text-ok" />Others only see your initials and locality. Requests reach you through the app, not your phone.</p>
          <input className="field" placeholder="Full name" value={f.name} onChange={set('name')} required />
          <div className="grid grid-cols-2 gap-3">
            <select className="field" value={f.bloodGroup} onChange={set('bloodGroup')} required>
              <option value="">Blood group</option>{groups.map((g) => <option key={g}>{g}</option>)}
            </select>
            <select className="field" value={f.locality} onChange={set('locality')} required>
              <option value="">Locality</option>{localities.map((l) => <option key={l}>{l}</option>)}
            </select>
          </div>
          <input className="field" inputMode="numeric" placeholder="Phone (10 digits)" value={f.phone} onChange={set('phone')} required />
          <button className="btn-red w-full">Register</button>
        </form>
        {msg && <p role="status" className="rounded-lg bg-ok-tint p-3 text-ok">{msg}</p>}

        <div className="rounded-xl border border-ink/10 bg-white p-5">
          <h2 className="font-bold">Registry ({list.length})</h2>
          <ul className="mt-2 max-h-80 divide-y divide-ink/10 overflow-auto text-sm">
            {list.map((x) => (
              <li key={x.id} className="flex justify-between py-1.5">
                <span><b>{x.initials}</b> · {x.locality}</span>
                <span><b className="text-blood">{x.bloodGroup}</b> · {x.ready ? 'available' : x.unlockAt ? `rests until ${new Date(x.unlockAt).toLocaleDateString()}` : 'unavailable'}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="space-y-4">
        <div className="rounded-xl border border-ink/10 bg-white p-5">
          <h2 className="font-bold">Act as a donor</h2>
          <p className="mb-2 text-sm text-ink/70">Demo shortcut in place of a login: pick who you are.</p>
          <select className="field" value={me} onChange={(e) => pick(e.target.value)}>
            <option value="">Choose a donor…</option>
            {list.map((x) => <option key={x.id} value={x.id}>{x.initials} · {x.bloodGroup} · {x.locality}</option>)}
          </select>
        </div>

        {d && (
          <>
            <div className="rounded-xl border border-ink/10 bg-white p-5">
              <p className="text-lg font-bold">{d.initials} <span className="text-blood">{d.bloodGroup}</span> · {d.locality}</p>
              <p className="text-sm text-ink/70">Phone: {d.phone}</p>
              {d.unlockAt ? (
                <p className="mt-3 rounded-lg bg-warn-tint p-3 text-warn">You donated recently. Availability is locked until {new Date(d.unlockAt).toLocaleDateString()} (90 day recovery).</p>
              ) : (
                <button onClick={toggle} className="btn-line mt-3">{d.available ? 'Pause: mark me unavailable' : 'Mark me available'}</button>
              )}
            </div>

            <div className="rounded-xl border border-blood/40 bg-white p-5">
              <h2 className="font-bold">Requests you can help with</h2>
              {mine.open.length === 0 && <p className="mt-2 text-ink/60">Nothing compatible is open right now.</p>}
              <ul className="mt-2 space-y-2">
                {mine.open.map((r) => (
                  <li key={r.id} className="rounded-lg border border-ink/10 p-3">
                    <Link to={`/request/${r.id}`} className="font-semibold underline">{r.units} × {r.bloodGroup} at {r.hospital}</Link>
                    <p className="text-sm text-ink/70">{r.distanceKm} km away, about {r.etaMin} min · {timeLeft(r.deadlineAt)} · {r.committed}/{r.units} committed</p>
                    <button className="btn-red mt-2" disabled={!d.ready || r.alreadyResponded || r.committed >= r.units} onClick={() => donate(r.id)}>
                      {r.alreadyResponded ? 'You are on the way' : 'I Can Donate'}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {mine.history.length > 0 && (
              <div className="rounded-xl border border-ink/10 bg-white p-5">
                <h2 className="font-bold">Your donations</h2>
                <input className="field mt-2" placeholder="Name to print on certificate" value={certName} onChange={(e) => setCertName(e.target.value)} />
                <ul className="mt-2 space-y-2">
                  {mine.history.map((h, i) => (
                    <li key={i} className="flex items-center justify-between text-sm">
                      <span>{h.bloodGroup} at {h.hospital} · {new Date(h.at).toLocaleDateString()}</span>
                      <button className="btn-line !py-1" onClick={() => drawCertificate(certName, h.bloodGroup, h.hospital)}><Download size={15} /> Certificate</button>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
