import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { CheckCircle2, MessageSquareShare, MapPin } from 'lucide-react';
import { api, tokens, timeLeft, usePoll } from '../api.js';
import Stepper from '../components/Stepper.jsx';

export default function RequestDetail() {
  const { id } = useParams();
  const [r, setR] = useState(null);
  const [donors, setDonors] = useState([]);
  const [radius, setRadius] = useState(15);
  const [sms, setSms] = useState(null);
  const [msg, setMsg] = useState('');
  const me = localStorage.getItem('rr_donor');
  const isOwner = !!tokens.get(id);

  usePoll(() => api.get(`/requests/${id}`).then(setR).catch((e) => setMsg(e.message)), 4000, [id]);
  usePoll(() => api.get(`/requests/${id}/donors?radius=${radius}`).then(setDonors).catch(() => {}), 8000, [id, radius]);

  if (!r) return <p>{msg || 'Loading…'}</p>;
  const live = r.status !== 'closed';

  const run = (fn, ok) => async () => {
    try { await fn(); setMsg(ok); setR(await api.get(`/requests/${id}`)); } catch (e) { setMsg(e.message); }
  };
  const donate = run(() => api.post(`/requests/${id}/respond`, { donorId: Number(me) }), 'Thank you. The family can see you are on the way.');
  const received = run(() => api.post(`/requests/${id}/close`, { token: tokens.get(id) }), 'Marked as received. Request closed.');
  const broadcast = async () => { try { setSms(await api.post(`/requests/${id}/broadcast`, { radius })); } catch (e) { setMsg(e.message); } };

  return (
    <div className="space-y-6">
      <section className="rounded-xl border border-ink/10 bg-white p-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="flex items-center gap-2 text-sm text-ink/70">{live && <span className="sos-dot" aria-hidden />}Patient {r.patient}</p>
            <h1 className="text-2xl font-extrabold">{r.units} unit{r.units > 1 ? 's' : ''} of {r.bloodGroup} at {r.hospital}</h1>
            <p className="mt-1 flex items-center gap-1 text-ink/70"><MapPin size={15} />{r.locality}{live && ` · ${timeLeft(r.deadlineAt)}`}</p>
          </div>
          <div className="text-right">
            <p className="text-4xl font-extrabold text-ok">{r.committed}/{r.units}</p>
            <p className="text-sm text-ink/70">units committed</p>
          </div>
        </div>
        <div className="mt-6"><Stepper status={r.status} /></div>
        {r.closedReason === 'expired' && <p className="mt-4 rounded-lg bg-warn-tint p-3 text-warn">This request expired after 24 hours. Post a new one if blood is still needed.</p>}
        {isOwner && live && (
          <button onClick={received} className="btn-red mt-5"><CheckCircle2 size={18} /> Mark blood received</button>
        )}
      </section>

      {msg && <p role="status" className="rounded-lg bg-ok-tint p-3 text-ok">{msg}</p>}

      {live && me && (
        <section className="rounded-xl border border-blood/40 bg-blood-tint p-5">
          <p className="mb-3 font-semibold">You are acting as the donor you picked on the Donors page.</p>
          <button onClick={donate} className="btn-red">I Can Donate</button>
        </section>
      )}
      {live && !me && <p className="text-sm text-ink/70">To respond as a donor, pick a donor profile on the Donors page first.</p>}

      <section className="rounded-xl border border-ink/10 bg-white p-5">
        <h2 className="font-bold">Responding donors</h2>
        {r.responses.length === 0 ? <p className="mt-2 text-ink/60">Nobody yet. Compatible donors have been notified.</p> : (
          <ul className="mt-3 divide-y divide-ink/10">
            {r.responses.map((x, i) => (
              <li key={i} className="flex justify-between py-2">
                <span><b>{x.initials}</b> · {x.bloodGroup} · {x.locality}</span>
                <span className="text-ok">{x.state === 'donated' ? 'Donated' : 'On the way'}</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="rounded-xl border border-ink/10 bg-white p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-bold">Compatible donors nearby</h2>
            <p className="text-sm text-ink/70">Can give to {r.bloodGroup}: {r.compatibleGroups.join(', ')}</p>
          </div>
          <label className="text-sm">Radius
            <select className="field ml-2 !w-auto" value={radius} onChange={(e) => setRadius(Number(e.target.value))}>
              {[5, 10, 15, 25, 50].map((k) => <option key={k} value={k}>{k} km</option>)}
            </select>
          </label>
        </div>
        <p className="mt-3 text-sm font-semibold">{donors.length} available within {radius} km</p>
        <ul className="mt-2 grid gap-2 sm:grid-cols-2">
          {donors.map((d) => (
            <li key={d.id} className="flex items-center justify-between rounded-lg border border-ink/10 p-3">
              <span><b>{d.initials}</b> · {d.locality}</span>
              <span className="text-sm text-ink/70"><b className="text-blood">{d.bloodGroup}</b> · {d.distanceKm} km · ~{d.etaMin} min</span>
            </li>
          ))}
        </ul>
        {live && <button onClick={broadcast} className="btn-line mt-4"><MessageSquareShare size={18} /> Simulate SMS alert</button>}
        {sms && (
          <div className="mt-4 space-y-2 rounded-lg bg-ink p-4 text-sm text-white">
            <p className="font-semibold">Simulated dispatch: {sms.length} message(s). Nothing was actually sent.</p>
            {sms.map((s, i) => <p key={i}><span className="text-white/60">To {s.to}:</span> {s.text}</p>)}
          </div>
        )}
      </section>
    </div>
  );
}
