import { Link, NavLink, Route, Routes } from 'react-router-dom';
import { Droplets } from 'lucide-react';
import Feed from './pages/Feed.jsx';
import NewRequest from './pages/NewRequest.jsx';
import RequestDetail from './pages/RequestDetail.jsx';
import Donors from './pages/Donors.jsx';

const link = ({ isActive }) =>
  `px-3 py-1.5 rounded-lg font-semibold ${isActive ? 'bg-ink text-white' : 'hover:bg-ink/10'}`;

export default function App() {
  return (
    <>
      <header className="border-b border-ink/15 bg-white">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-4 py-3">
          <Link to="/" className="flex items-center gap-2 text-xl font-extrabold tracking-tight text-blood">
            <Droplets size={26} /> RedRelay
          </Link>
          <nav className="flex gap-1 text-sm">
            <NavLink to="/" end className={link}>Live requests</NavLink>
            <NavLink to="/sos" className={link}>Request blood</NavLink>
            <NavLink to="/donors" className={link}>Donors</NavLink>
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-4 py-6">
        <Routes>
          <Route path="/" element={<Feed />} />
          <Route path="/sos" element={<NewRequest />} />
          <Route path="/request/:id" element={<RequestDetail />} />
          <Route path="/donors" element={<Donors />} />
        </Routes>
      </main>
    </>
  );
}
